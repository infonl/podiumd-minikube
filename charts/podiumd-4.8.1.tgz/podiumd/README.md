# PodiumD

## PodiumD versions

### [4.8.0](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.8.0)

**PodiumD Helm chart version: 4.8.0**
Release scoped around the Open Inwoner upgrade 2.1.2 → 2.3.1 (chart
2.1.3 → 2.2.1), spanning upstream 2.2.0 (Django CMS v3 → v4) and 2.3.0
(opt-in ClamAV virus scanning, ZGW cache-warmup + low-latency worker).
4.8.0 also carries the 4.7.4/4.7.5/4.7.6/4.7.7 work (Keycloak 26.6.3, Open Zaak
1.27.3, ZGW Office Add-in 0.9.313, Open Formulieren logging revert); all other
components remain at their 4.7.7 baseline. Zie
`docs/_UPGRADE_PATHS/4.7.8-to-4.8.0-upgrade.md` voor details.

| Component                 | AppVersion       | Change            | ChartVersion | Change         | **Notes**                            |
|---------------------------|------------------|-------------------|--------------|----------------|--------------------------------------|
| Open Inwoner              | 2.3.1            | Minor update      | 2.2.1        | Minor update   | CMS v3→v4, opt-in ClamAV virus scan  |
| Open Zaak                 | 1.27.3           | Patch update      | 1.14.1       |                | 4.7.7 patch folded in                |

### [4.7.4](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.7.4)

**PodiumD Helm chart version: 4.7.4**
Security patch release. Keycloak server + operator 26.6.2 → 26.6.3 (16 CVEs,
notably CVE-2026-9704 token-exchange privilege escalation, CVE-2026-4874 SSRF,
CVE-2026-9802 refresh-token replay), with the adfinis keycloak-operator chart
1.11.4 → 1.12.0 (appVersion 26.6.3); the 26.6.3 CRDs are byte-identical to
26.6.2, so no CRD apply is required. Open Zaak 1.27.1 → 1.27.2 (CVE-2026-54657
`_zoek` authorization filtering + document bulk-import path-traversal fix). Also
adds a Datamigratie Keycloak client and Open Zaak credentials (config only, no
image change). See `docs/_UPGRADE_PATHS/4.7.3-to-4.7.4-upgrade.md`.

| Component                 | AppVersion       | Change            | ChartVersion | Change         | **Notes**                            |
|---------------------------|------------------|-------------------|--------------|----------------|--------------------------------------|
| Keycloak                  | 26.6.3           | Security update   | 1.12.0       | Minor update   | Adfinis operator; 26.6.3 fixes 16 CVEs |
| - Keycloak-config-cli     | 6.5.0-26         |                   |              |                |                                      |
| Open Zaak                 | 1.27.2           | Security update   | 1.14.1       |                | CVE-2026-54657 (`_zoek` authz) + bulk-import path traversal |

### [4.7.3](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.7.3)

**PodiumD Helm chart version: 4.7.3**
Patch release scoped around a ZAC hotfix for mail-template rendering
(ZAC 4.7.1 → 4.7.2). All other components remain at their 4.7.2
baseline; see the `4.7.2` row below for the unchanged entries.

| Component                 | AppVersion       | Change            | ChartVersion | Change         | **Notes**                            |
|---------------------------|------------------|-------------------|--------------|----------------|--------------------------------------|
| Zac                       | 4.7.2            | Patch update      | 1.0.228      |                | Mail-template hotfix                 |

### [4.7.2](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.7.2)

**PodiumD Helm chart version: 4.7.2**
Componenten op alphabetische volgorde, met sub-charts er onder. Wijzigingen
tegen `4.6.3` (laatste hier vastgelegde release; 4.7.0 en 4.7.1 zaten
tussen). Beveiligingsupdates in deze release: Keycloak 26.6.2 (account-takeover-
class CVEs) en nginx-unprivileged 1.30.2 (CVE-2026-42945 "nginx Rift" RCE
en CVE-2026-9256). Zie `docs/_UPGRADE_PATHS/4.7.1-to-4.7.2-upgrade.md` voor details.

| Component                 | AppVersion       | Change            | ChartVersion | Change         | **Notes**                            |
|---------------------------|------------------|-------------------|--------------|----------------|--------------------------------------|
| APISIX                    | 3.16.0-ubuntu    | New               | 2.14.0       | New            | Opt-in egress gateway (apisix.enabled) |
| BRP Mock                  |                  |                   | 1.2.8        |                | Only on Test Environments            |
| ClamAV                    | 1.4.4            |                   | 3.7.1        |                |                                      |
| ITA                       | 3.1.0            | Patch update      | 3.1.0        | Patch update   |                                      |
| - Ita poller              | 3.1.0            | Patch update      |              |                |                                      |
| Keycloak                  | 26.6.2           | Minor + security  | 1.11.4       | Patch update   | Adfinis operator, +security 26.6.2   |
| - Keycloak-config-cli     | 6.5.0-26         |                   |              |                |                                      |
| - Curl                    | 8.20.0           | Patch update      |              |                |                                      |
| Kiss                      | 2.2.2            |                   | 2.2.2        |                |                                      |
| - Kiss Elastic            |                  |                   | 1.1.0        |                |                                      |
| - Kiss ElasticSync        | 0.3.2            |                   |              |                |                                      |
| - PodiumD Adapter         | 0.6.6            |                   |              |                |                                      |
| Objecten                  | 3.6.0            |                   | 2.12.0       |                |                                      |
| Objecttypen               | 3.4.2            | Patch update      | 1.6.1        |                |                                      |
| OMC for NotifyNL          | 1.17.19          | Patch update      | 0.14.1       | Patch update   |                                      |
| Open Archiefbeheer        | 2.0.0            | Major update      | 2.0.0        | Major update   |                                      |
| Open Beheer               | 0.9.0            | New               | 0.1.3        | New            |                                      |
| Open Formulieren          | 3.4.9            | Patch update      | 1.12.0       |                |                                      |
| Open Inwoner              | 2.1.2            | Patch update      | 2.1.3        |                | Stable 2.1.2 — never use 2.1.2-rc1   |
| Open Klant                | 2.15.0           |                   | 1.11.0       |                |                                      |
| Open Notificaties         | 1.15.0           |                   | 1.13.1       |                |                                      |
| Open Zaak                 | 1.27.1           | Minor update      | 1.14.1       | Minor update   | New optional Azure Blob / S3 backends |
| PABC                      | 1.1.0            |                   | 1.1.0        |                |                                      |
| - k8s-wait-for            | v2.0             |                   |              |                |                                      |
| Redis Operator            | v0.24.0          |                   | 0.24.0       |                |                                      |
| - Busybox                 | 1.37.0-glibc     |                   |              |                |                                      |
| - Kubectl                 | 1.34.7           | Minor update      |              |                | alpine/k8s image                     |
| - Redis                   | v8.6.2           |                   |              |                |                                      |
| - Redis Exporter          | v1.82.0          |                   |              |                |                                      |
| Referentielijsten         | 0.7.2            | New               | 0.1.1        | New            |                                      |
| nginx-unprivileged        | 1.30.2           | Minor + security  |              |                | Shared sidecar for all Django apps   |
| Zac                       | 4.7.1            | Major update      | 1.0.228      | Minor update   |                                      |
| - Opa                     | 1.15.2-static    | Minor update      |              |                |                                      |
| - Opentelemetry Collector | 0.150.1          | Minor update      |              |                | Operator                             |
| - Solr                    | 9.10.1-slim      |                   | 0.9.1        |                | CVE-2026-22022 + CVE-2026-22444 in 9.10.1 |
| - Gotenberg               | 8.31.0           |                   |              |                | Office converter                     |
| - Zookeeper               | 0.2.15           |                   | 0.2.15       |                | Operator                             |
| ZGW Office Addin          | v0.9.289         | Minor update      | 0.0.87       | Patch update   |                                      |

### [4.6.3](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.6.3)

**PodiumD Helm chart version: 4.6.3**
Componenten op alphabetische volgorde, met sub-charts er onder:

| Component                 | AppVersion   | Change        | ChartVersion | Change        | **Notes**                 |
|---------------------------|--------------|---------------|--------------|---------------|---------------------------|
| BRP Mock                  |              |               | 1.2.8        |               | Only on Test Environments |
| ClamAV                    | 1.4.4        |               | 3.7.1        |               |                           |
| ITA                       | 3.0.0        |               | 3.0.0        |               |                           |
| - Ita poller              | 3.0.0        |               |              |               |                           |
| Keycloak                  | 26.5.7       |               | 1.11.2       |               |                           |
| - Keycloak-config-cli     | 6.5.0-26     | Minor update  |              |               |                           |
| - Curl                    | 8.19.0       | Patch update  |              |               |                           |
| Kiss                      | 2.2.2        |               | 2.2.2        |               |                           |
| - Kiss Elastic            |              |               | 1.1.0        |               |                           |
| - Kiss ElasticSync        | 0.3.2        |               |              |               |                           |
| - PodiumD Adapter         | 0.6.6        |               |              |               |                           |
| Objecten                  | 3.6.0        |               | 2.12.0       |               |                           |
| Objecttypen               | 3.4.1        |               | 1.6.1        |               |                           |
| OMC for NotifyNL          | 1.17.18      |               | 0.14.0       |               |                           |
| Open Archiefbeheer        | 1.1.1        |               | 1.5.3        |               |                           |
| Open Formulieren          | 3.4.7        |               | 1.12.0       |               |                           |
| Open Inwoner              | 2.1.1        |               | 2.1.3        |               |                           |
| Open Klant                | 2.15.0       |               | 1.11.0       |               |                           |
| Open Notificaties         | 1.15.0       |               | 1.13.1       |               |                           |
| Open Zaak                 | 1.26.0       |               | 1.13.1       |               |                           |
| PABC                      | 1.1.0        |               | 1.1.0        |               |                           |
| - k8s-wait-for            | v2.0         |               |              |               |                           |
| Redis Operator            | v0.24.0      |               | 0.24.0       |               |                           |
| - Busybox                 | 1.37.0-glibc |               |              |               |                           |
| - Kubectl                 | 1.33.2       | Minor update  |              |               | alpine/k8s image          |
| - Redis                   | v8.6.2       | Minor update  |              |               |                           |
| - Redis Exporter          | v1.82.0      | Minor update  |              |               |                           |
| Zac                       | 4.3.61       |               | 1.0.208      |               |                           |
| - Busybox                 | 1.37.0       |               |              |               |                           |
| - Curl                    | 8.18.0       |               |              |               |                           |
| - Kubectl                 | 1.25.4       |               |              |               |                           |
| - Nginx                   | 1.29.5       |               |              |               |                           |
| - Opa                     | 1.14.0       |               |              |               |                           |
| - Opentelemetry Collector | 0.146.1      |               | 0.146.0      |               | Operator                  |
| - Solr                    | 9.10.1       |               | 0.9.1        |               |                           |
| - Office Converter        | 1.8.2        |               |              |               |                           |
| - Zookeeper               | 0.2.15       |               | 0.2.15       |               | Operator                  |
| ZGW Office Addin          | 0.9.251      | Minor update  | 0.0.83       | Minor update  |                           |

### [4.5.14](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.5.14)

**PodiumD Helm chart version: 4.5.14**

| Component          | AppVersion | Change       | ChartVersion | Change                                  |
|--------------------|------------|--------------|--------------|-----------------------------------------|
| ClamAV             | 1.4.2      |              | 3.2.0        |                                         |
| Keycloak           | 26.5.6     | Minor update | 1.11.2       | Bitnami vervangen met Adfinis Operator  |
| Infinispan         | 15.2       |              | 0.5.0        |                                         |
| ITA                | 2.0.1      | Patch update | 2.0.1        | Patch update                            |
| PABC               | 1.0.0      | New          | 1.0.0        | New                                     |
| Objecten           | 3.5.0      | Minor update | 2.11.0       | Minor update                            |
| Objecttypen        | 3.4.0      | Minor update | 1.6.0        | Minor update                            |
| Open Formulieren   | 3.3.9      | Patch update | 1.11.6       |                                         |
| Open Inwoner       | 2.0.4      | Major update | 2.1.0        | Major update                            |
| Open Klant         | 2.14.0     | Minor update | 1.10.0       | Minor update                            |
| Open Notificaties  | 1.14.0     | Minor update | 1.13.0       | Minor update                            |
| Open Zaak          | 1.26.0     | Minor update | 1.13.0       | Minor update                            |
| Open Archiefbeheer | 1.1.1      |              | 1.5.3        | Minor update                            |
| Kiss               | 2.1.0      | Major update | 2.1.0        | Major update                            |
| Zac                | 4.0.12-1   | Major update | 1.0.165      | Minor update                            |
| ZGW Office Addin   | 0.9.28     | Minor update | 0.0.65       | Patch update                            |

### [4.4.5](https://github.com/Dimpact-Samenwerking/helm-charts/releases/tag/podiumd-4.4.5)

**PodiumD Helm chart version: 4.4.5**

| Component          | AppVersion | Change       | ChartVersion | Change          |
|--------------------|------------|--------------|--------------|-----------------|
| ClamAV             | 1.4.2      |              | 3.2.0        |                 |
| Keycloak           | 26.3.1     |              | 24.8.0       |                 |
| Infinispan         | 15.2       |              | 0.5          |                 |
| ITA                | 2.0.1      | Major update | 2.0.1        |  Major update   |
| Objecten           | 3.3.1      | Minor update | 2.10.0       |  Minor update   |
| Objecttypen        | 3.3.0      | Minor update | 1.5.0        |  Minor update   |
| Open Formulieren   | 3.3.9      | Minor update | 1.11.6       |  Minor update   |
| Open Inwoner       | 1.35.3     | Minor update | 1.12.0       |  Minor update   |
| Open Klant         | 2.13.0     | Minor update | 1.9.0        |  Minor update   |
| Open Notificaties  | 1.13.0     | Minor update | 1.12.0       |  Minor update   |
| Open Zaak          | 1.25.0     | Minor update | 1.12.0       |  Minor update   |
| Open Archiefbeheer | 1.1.1      | Minor update | 1.4.1        |                 |
| Kiss               | 1.3.1      |              |              |                 |
| Zac                | 3.18.0     | Minor update | 1.0.137      |                 |
| ZGW Office Addin   | 0.2.50     | Minor update | 0.0.42       |                 |

## Add Used chart repositories:

```shell
helm repo add dimpact https://Dimpact-Samenwerking.github.io/helm-charts/
helm repo add kiss-frontend https://raw.githubusercontent.com/Klantinteractie-Servicesysteem/KISS-frontend/main/helm
helm repo add kiss-adapter https://raw.githubusercontent.com/ICATT-Menselijk-Digitaal/podiumd-adapter/main/helm
helm repo add maykinmedia https://maykinmedia.github.io/charts
helm repo add wiremind https://wiremind.github.io/wiremind-helm-charts
helm repo add solr https://solr.apache.org/charts
helm repo add opentelemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo add zac https://infonl.github.io/dimpact-zaakafhandelcomponent/
helm repo add zgw-office-addin https://infonl.github.io/zgw-office-addin
helm repo add adfinis https://charts.adfinis.com
helm repo add worth-nl https://worth-nl.github.io/helm-charts
helm repo add apisix https://charts.apiseven.com
```

## PersistentVolume and PersistVolumeClaim resources

PersistentVolume and PersistentVolumeClaim resources are:
- created during a Helm install or upgrade if the PersistentVolumeClaim referenced by the `persistence.existingClaim` parameter does not yet exist
- never deleted during a Helm uninstall

In order to determine whether the combination of PersistentVolume and PersistentVolumeClaim should be created,
the existence of the PersistentVolumeClaim referenced by the `persistence.existingClaim` parameter of the subchart, is checked.
If the referenced PersistentVolumeClaim does not exist both the PersistentVolume and PersistentVolumeClaim are created during Helm install.

As the PersistentVolume and PersistentVolumeClaim are never deleted during a Helm uninstall, they can be reused by the next Helm install.
PersistentVolume and PersistentVolumeClaim resources can only be manually deleted or updated after a Helm uninstall.
If they are deleted they will be recreated during the next Helm install.
If they are updated they will be reused by the next Helm install.
The following parameters impact the creation of PersistentVolume reources

| Name                                          | Description                                                                                                                                          | Value |
|-----------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| persistentVolume.volumeAttributeShareName     | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overrides the `volumeAttributeShareName` parameter per subchart | `""`  |
| persistentVolume.volumeAttributeResourceGroup | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.resourceGroup`                                                                  | `""`  |
| persistentVolume.nodeStageSecretRefName       | Value of created PersistentVolume paramer `spec.csi.nodeStageSecretRef.name`                                                                         | `""`  |
| persistentVolume.nodeStageSecretRefNamespace  | Value of created PersistentVolume paramer `spec.csi.nodeStageSecretRef.namespace`                                                                    | `""`  |

## Parameters

### Global

The following components can be partially configured:
- Open Zaak
- Open Notificaties

Kanalen will only be added to Open Notificaties during Helm install, not on Helm upgrade.

| Name                                              | Description                                                                 | Value                                                           |
|---------------------------------------------------|-----------------------------------------------------------------------------|-----------------------------------------------------------------|
| global.configuration.enabled                      | Whether component configuration is enabled                                  | `true`                                                          |
| global.configuration.overwrite                    | Whether existing component configuration is overwritten                     | `true`                                                          |
| global.configuration.organization                 | Organization name                                                           | `Example gemeente`                                              |
| global.configuration.openzaakAutorisatiesApi      | Autorisaties API                                                            | `http//openzaak.podiumd.svc.cluster.local/autorisaties/api/v1/` |
| global.configuration.notificatiesApi              | Notificaties API                                                            | `http://opennotificaties.podiumd.svc.cluster.local/api/v1/`     |
| global.configuration.notificatiesOpenzaakClientId | ClientId used by Open Notificaties to access autorisaties API               | `notificaties`                                                  |
| global.configuration.notificatiesOpenzaakSecret   | Secret used by Open Notificaties to access autorisaties API                 | `notificaties-secret`                                           |
| global.configuration.openzaakNotificatiesClientId | ClientId used by Open Zaak to send notifications                            | `openzaak`                                                      |
| global.configuration.openzaakNotificatiesSecret   | Secret used by Open Zaak to send notifications                              | `openzaak-secret`                                               |
| global.imageRegistry                              | Image registry used by Keycloak, Redis, RabitMQ and Elastic                 | `""`                                                            |
| global.settings.databaseHost                      | Database host used bij objecten, objecttypen, openinwoner, opennotificaties | `""`                                                            |

### keycloak-operator

The Keycloak Operator is deployed via the [adfinis/keycloak-operator](https://artifacthub.io/packages/helm/adfinis/keycloak-operator) Helm chart, which wraps the official upstream Keycloak Operator manifests from [keycloak/keycloak-k8s-resources](https://github.com/keycloak/keycloak-k8s-resources). It installs the `Keycloak` CRD (`k8s.keycloak.org/v2beta1`) and reconciles `Keycloak` custom resources into running pods.

The deprecated Bitnami `keycloak` sub-chart (`keycloak.enabled`) is kept for rollback purposes only and will be removed in a future release. See `docs/apps/keycloak/migrating-to-keycloak-operator.md` for migration instructions.

| Name                                           | Description                                                                          | Value                                    |
|------------------------------------------------|--------------------------------------------------------------------------------------|------------------------------------------|
| keycloak-operator.enabled                      | Deploy the Keycloak Operator (adfinis/keycloak-operator chart)                       | `true`                                   |
| keycloak-operator.operator.image.repository    | Keycloak Operator controller image repository                                        | `quay.io/keycloak/keycloak-operator`     |
| keycloak-operator.operator.image.tag           | Keycloak Operator controller image tag                                               | `26.6.3`                                 |
| keycloak.enabled                               | Deploy legacy Bitnami Keycloak sub-chart (deprecated, use keycloak-operator instead) | `false`                                  |
| keycloak.name                                  | Name of the `Keycloak` CR created by `keycloak-cr.yaml`                              | `keycloak`                               |
| keycloak.instances                             | Number of Keycloak replicas                                                          | `2`                                      |
| keycloak.image.tag                             | Keycloak application image tag                                                       | `26.6.3`                                 |
| keycloak.hostname.hostname                     | Public hostname for the Keycloak service                                             | `""`                                     |
| keycloak.hostname.admin                        | Hostname for the Keycloak admin console                                              | `""`                                     |
| keycloak.http.httpEnabled                      | Enable plain HTTP (required when running behind a reverse proxy)                     | `true`                                   |
| keycloak.proxy.headers                         | Proxy header forwarding mode (e.g. `xforwarded`)                                    | `""`                                     |
| keycloak.auth.adminUser                        | Initial bootstrap admin username                                                     | `admin`                                  |
| keycloak.auth.adminPassword                    | Initial bootstrap admin password                                                     | `ChangeMeNow`                            |
| keycloak.externalDatabase.host                 | PostgreSQL database host                                                             | `""`                                     |
| keycloak.externalDatabase.database             | PostgreSQL database name                                                             | `""`                                     |
| keycloak.externalDatabase.user                 | PostgreSQL database username                                                         | `""`                                     |
| keycloak.externalDatabase.password             | PostgreSQL database password                                                         | `""`                                     |
| keycloak.secretsName                           | Name of the Secret containing DB credentials for the operator                        | `keycloak-secrets`                       |
| keycloak.config.realmFrontendUrl               | URL of Keycloak for end-user login (podiumd realm)                                   | `https://keycloak.example.nl`            |
| keycloak.config.adminFrontendUrl               | URL of Keycloak for admin console login (master realm)                               | `https://keycloak-admin.example.nl`      |
| keycloak.nodeSelector                          | Node labels for Keycloak pod assignment                                              | `{}`                                     |
| keycloak.resources                             | Container resource requests and limits                                               | See values.yaml                          |


### ClamAV

| Name                    | Description                                                                    | Value           |
|-------------------------|--------------------------------------------------------------------------------|-----------------|
| clamav.enabled          | Boolean to override the installation of ClamAV                                 |                 |
| clamav.clamdConfig      | Override default clamd.conf file. (https://linux.die.net/man/5/clamd.conf)     | see Chart.yaml  |
| clamav.freshclamConfig  | Override default clamd.conf file. (https://linux.die.net/man/5/freshclam.conf) | see Chart.yaml  |
| clamav.image.repository | Image repository                                                               | `clamav/clamav` |
| clamav.image.tag        | Image tag                                                                      | `1.3.1`         |
| clamav.image.pullPolicy | Image pull policy                                                              | `IfNotPresent`  |
| clamav.nodeSelector     | Node labels for pod assignment. Evaluated as a template                        | `{}`            |
| clamav.resources        | Container requests and limits                                                  | See values.yaml |


### BRP Mock

| Name                              | Description                                             | Value                                                 |
|-----------------------------------|---------------------------------------------------------|-------------------------------------------------------|
| brpmock.enabled                   | Boolean to override the installation of BRP Mock        | `false`                                               |
| brpmock.nodeSelector              | Node labels for pod assignment. Evaluated as a template | `{}`                                                  |
| brpmock.brpproxy.image.repository | Proxy image repository                                  | `iswish/haal-centraal-brp-bevragen-proxy`             |
| brpmock.brpproxy.image.tag        | Proxy image tag                                         | `2.0.20`                                              |
| brpmock.brpproxy.image.pullPolicy | Proxy image pull policy                                 | `IfNotPresent`                                        |
| brpmock.brpproxy.resources        | Proxy container requests and limits                     | See values.yaml                                       |
| brpmock.gbamock.image.repository  | Mock image repository                                   | `ghcr.io/brp-api/haal-centraal-brp-bevragen-gba-mock` |
| brpmock.gbamock.image.tag         | Mock image tag                                          | `2.0.8`                                               |
| brpmock.gbamock.image.pullPolicy  | Mock image pull policy                                  | `IfNotPresent`                                        |
| brpmock.gbamock.resources         | Mock container requests and limits                      | See values.yaml                                       |


### Open Zaak

| Name                                               | Description                                                                                                                                           | Value                                                          |
|----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------|
| openzaak.enabled                                   | Boolean to override the installation of Open Zaak                                                                                                     |                                                                |
| openzaak.configuration.data | string | `""` |  |
| openzaak.configuration.enabled | bool | `true` |  |
| openzaak.configuration.initContainer.enabled | bool | `false` |  |
| openzaak.configuration.job.backoffLimit | int | `6` |  |
| openzaak.configuration.job.enabled | bool | `true` |  |
| openzaak.configuration.job.resources | object | `{}` |  |
| openzaak.configuration.job.restartPolicy | string | `"Never"` |  |
| openzaak.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| openzaak.configuration.oidcSecret | string | `"<openzaak>"` |  |
| openzaak.configuration.oidcUrl | string | `"https://openzaak.example.nl"` |  |
| openzaak.configuration.secrets | object | `{}` |  |
| openzaak.settings.allowedHosts                     | List if allowed hostnames<br/>(i.e. "openzaak.example.nl,openzaak-nginx.podiumd.svc.cluster.local")                                                   | `openzaak-nginx.podiumd.svc.cluster.local`                     |
| openzaak.settings.database.host                    | Database host                                                                                                                                         | `""`                                                           |
| openzaak.settings.database.name                    | Database name                                                                                                                                         | `""`                                                           |
| openzaak.settings.database.username                | Database username                                                                                                                                     | `""`                                                           |
| openzaak.settings.database.password                | Database user password                                                                                                                                | `""`                                                           |
| openzaak.settings.database.sslmode                 | Database SSL mode                                                                                                                                     | `prefer`                                                       |
| openzaak.settings.email.host                       | Email host                                                                                                                                            | `localhost`                                                    |
| openzaak.settings.email.port                       | Email port                                                                                                                                            | `587`                                                          |
| openzaak.settings.email.username                   | Email username                                                                                                                                        | `""`                                                           |
| openzaak.settings.email.password                   | Email user password                                                                                                                                   | `""`                                                           |
| openzaak.settings.email.useTLS                     | Email use TLS                                                                                                                                         | `true`                                                         |
| openzaak.settings.secretKey                        | Django secret key. Generate secret key at https://djecrety.ir/                                                                                        | `""`                                                           |
| openzaak.settings.environment                      | Sets the `ENVIRONMENT` variable                                                                                                                       | `""`                                                           |
| openzaak.settings.isHttps                          | Use HTTPS                                                                                                                                             | `true`                                                         |
| openzaak.settings.debug                            | Enable debug mode                                                                                                                                     | `false`                                                        |
| openzaak.settings.numProxies                       | Number of proxies                                                                                                                                     | `1`                                                            |
| openzaak.settings.sentry.dsn                       | Url to Sentry (i.e https://sentry.example.com/111)                                                                                                    | `""`                                                           |
| openzaak.persistence.existingClaim                 | Manually managed Persistent Volume and Claim                                                                                                          | `openzaak`                                                     |
| openzaak.persistence.mediaMountSubpath             | Media mount subpath                                                                                                                                   | `openzaak/media`                                               |
| openzaak.persistence.privateMediaMountSubpath      | Private media mount subpath                                                                                                                           | `openzaak/private_media`                                       |
| openzaak.persistence.size                          | Size of created PersistentVolume                                                                                                                      | `10Gi`                                                         |
| openzaak.persistentVolume.volumeAttributeShareName | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overriden by `.Values.persistentVolume.volumeAttributeShareName` | `openzaak`                                                     |
| openzaak.image.repository                          | Image repository                                                                                                                                      | `openzaak/open-zaak`                                           |
| openzaak.image.tag                                 | Image tag                                                                                                                                             | `1.15.0`                                                       |
| openzaak.image.pullPolicy                          | Image pull policy                                                                                                                                     | `IfNotPresent`                                                 |
| openzaak.nodeSelector                              | Node labels for pod assignment. Evaluated as a template                                                                                               | `{}`                                                           |
| openzaak.resources                                 | Container requests and limits                                                                                                                         | See values.yaml                                                |
| openzaak.worker.resources                          | Worker container requests and limits                                                                                                                  | See values.yaml                                                |
| openzaak.nginx.image.repository                    | Nginx image repository                                                                                                                                | `nginxinc/nginx-unprivileged`                                  |
| openzaak.nginx.image.tag                           | Mginx image tag                                                                                                                                       | `stable`                                                       |
| openzaak.nginx.image.pullPolicy                    | Nginx image pull policy                                                                                                                               | `IfNotPresent`                                                 |
| openzaak.nginx.resources                           | Nginx container requests and limits                                                                                                                   | See values.yaml                                                |
| openzaak.redis.image.registry                      | Redis image registry                                                                                                                                  | `docker.io`                                                    |
| openzaak.redis.image.repository                    | Redis image repository                                                                                                                                | `bitnami/redis`                                                |
| openzaak.redis.image.tag                           | Redis image tag                                                                                                                                       | `7.0.5-debian-11-r25`                                          |
| openzaak.redis.image.pullPolicy                    | Redis image pul policy                                                                                                                                | `IfNotPresent`                                                 |
| openzaak.redis.master.nodeSelector                 | Redis node labels for pod assignment. Evaluated as a template                                                                                         | `{}`                                                           |

### Open Notificaties

| Name                                                                 | Description                                                                                                                                           | Value                                        |
|----------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------|
| opennotificaties.enabled                                             | Boolean to override the installation of Open Notificatues                                                                                             | `true`                                       |
| opennotificaties.configuration.data | string | `""` |  |
| opennotificaties.configuration.enabled | bool | `true` |  |
| opennotificaties.configuration.http_request_job.enabled | bool | `false` |  |
| opennotificaties.configuration.initContainer.enabled | bool | `false` |  |
| opennotificaties.configuration.job.backoffLimit | int | `6` |  |
| opennotificaties.configuration.job.enabled | bool | `true` |  |
| opennotificaties.configuration.job.resources | object | `{}` |  |
| opennotificaties.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| opennotificaties.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| opennotificaties.configuration.oidcSecret | string | `"<opennotificaties>"` |  |
| opennotificaties.configuration.oidcUrl | string | `"https://opennotificaties.example.nl"` |  |
| opennotificaties.configuration.overwrite | bool | `true` |  |
| opennotificaties.configuration.secrets | object | `{}` |  |                                 |
| opennotificaties.settings.allowedHosts                               | List if allowed hostnames<br/>(i.e. "openzaak.example.nl,openzaak-nginx.podiumd.svc.cluster.local")                                                   | `opennotificaties.podiumd.svc.cluster.local` |
| opennotificaties.settings.database.host                              | Database host. Overides global.settings.databaseHost                                                                                                  | `""`                                         |
| opennotificaties.settings.database.port                              | Database port                                                                                                                                         | `5432`                                       |
| opennotificaties.settings.database.name                              | Database name                                                                                                                                         | `""`                                         |
| opennotificaties.settings.database.username                          | Database username                                                                                                                                     | `""`                                         |
| opennotificaties.settings.database.password                          | Database user password                                                                                                                                | `""`                                         |
| opennotificaties.settings.database.sslmode                           | Database SSL mode                                                                                                                                     | `prefer`                                     |
| opennotificaties.settings.email.host                                 | Email host                                                                                                                                            | `localhost`                                  |
| opennotificaties.settings.email.port                                 | Email port                                                                                                                                            | `587`                                        |
| opennotificaties.settings.email.username                             | Email username                                                                                                                                        | `""`                                         |
| opennotificaties.settings.email.password                             | Email user password                                                                                                                                   | `""`                                         |
| opennotificaties.settings.email.useTLS                               | Email use TLS                                                                                                                                         | `true`                                       |
| opennotificaties.settings.secretKey                                  | Django secret key. Generate secret key at https://djecrety.ir/                                                                                        | `""`                                         |
| opennotificaties.settings.environment                                | Sets the `ENVIRONMENT` variable                                                                                                                       | `""`                                         |
| opennotificaties.settings.isHttps                                    | Use HTTPS                                                                                                                                             | `true`                                       |
| opennotificaties.settings.debug                                      | Enable debug mode                                                                                                                                     | `false`                                      |
| opennotificaties.settings.cleanOldNotifications.enabled              | Enable leaning of logged notifications                                                                                                                | `true`                                       |
| opennotificaties.settings.cleanOldNotifications.daysRetained         | Number of days to retain logged notifications                                                                                                         | `30`                                         |
| opennotificaties.settings.cleanOldNotifications.cronjob.schedule     | Schedule to run the clean logged notifications cronjob                                                                                                | `"0 0 * * *"`                                |
| opennotificaties.settings.cleanOldNotifications.cronjob.historyLimit | Number of succesful and failed jobs to keep                                                                                                           | `1`                                          |
| opennotificaties.settings.maxRetries                                 | Maximum number of automatic retries. After this amount of retries,<br/>Open Notificaties stops trying to deliver the message                          | `5`                                          |
| opennotificaties.settings.retryBackoff                               | A factor applied to the exponential backoff.<br/>This allows you to tune how quickly automatic retries are performed                                  | `3`                                          |
| opennotificaties.settings.retryBackoffMax                            | Upper limit to the exponential backoff time                                                                                                           | `48`                                         |
| opennotificaties.settings.requestsTimeout                            | Timeout in seconds for HTTP requests.                                                                                                           | `60`                                         |
| opennotificaties.settings.numProxies                                 | Number of proxies                                                                                                                                     | `1`                                          |
| opennotificaties.settings.sentry.dsn                                 | Url to Sentry (i.e https://sentry.example.com/111)                                                                                                    | `""`                                         |
| opennotificaties.persistence.existingClaim                           | Manually managed Persistent Volume and Claim                                                                                                          | `opennotificaties`                           |
| opennotificaties.persistence.mediaMountSubpath                       | Media mount subpath                                                                                                                                   | `opennotificaties/media`                     |
| opennotificaties.persistence.size                                    | Size of created PersistentVolume                                                                                                                      | `10Gi`                                       |
| opennotificaties.persistentVolume.volumeAttributeShareName           | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overriden by `.Values.persistentVolume.volumeAttributeShareName` | `opennotificaties`                           |
| opennotificaties.image.repository                                    | Image repository                                                                                                                                      | `openzaak/open-notificaties`                 |
| opennotificaties.image.tag                                           | Image tag                                                                                                                                             | `1.7.1`                                      |
| opennotificaties.image.pullPolicy                                    | Image pull policy                                                                                                                                     | `IfNotPresent`                               |
| opennotificaties.nodeSelector                                        | Node labels for pod assignment. Evaluated as a template                                                                                               | `{}`                                         |
| opennotificaties.resources                                           | Container requests and limits                                                                                                                         | See values.yaml                              |
| opennotificaties.worker.resources                                    | Worker container requests and limits                                                                                                                  | See values.yaml                              |
| opennotificaties.rabbitmq.auth.username                              | RabitMQ username                                                                                                                                      | `guest`                                      |
| opennotificaties.rabbitmq.auth.password                              | RabitMQ user password                                                                                                                                 | `guest`                                      |
| opennotificaties.rabbitmq.auth.erlangCookie                          | RabitMQ erlang cookie                                                                                                                                 | `SUPER-SECRET`                               |
| opennotificaties.rabbitmq.image.repository                           | RabitMQ image repository                                                                                                                              | `bitnami/rabbitmq`                           |
| opennotificaties.rabbitmq.image.tag                                  | RabitMQ image tag                                                                                                                                     | `3.11.8-debian-11-r0`                        |
| opennotificaties.rabbitmq.image.pullPolicy                           | RabitMQ image pul policy                                                                                                                              | `IfNotPresent`                               |
| opennotificaties.rabbitmq.nodeSelector                               | RabitMQ node labels for pod assignment. Evaluated as a template                                                                                       | `{}`                                         |
| opennotificaties.rabbitmq.resources                                  | RabitMQ container requests and limits                                                                                                                 | See values.yaml                              |
| opennotificaties.redis.image.registry                                | Redis image registry                                                                                                                                  | `docker.io`                                  |
| opennotificaties.redis.image.repository                              | Redis image repository                                                                                                                                | `bitnami/redis`                              |
| opennotificaties.redis.image.tag                                     | Redis image tag                                                                                                                                       | `7.0.5-debian-11-r25`                        |
| opennotificaties.redis.image.pullPolicy                              | Redis image pul policy                                                                                                                                | `IfNotPresent`                               |
| opennotificaties.redis.master.nodeSelector                           | Redis node labels for pod assignment. Evaluated as a template                                                                                         | `{}`                                         |

### Objecten

| Name                                               | Description                                                                                                                                           | Value                                |
|----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------|
| objecten.enabled                                   | Boolean to override the installation of Objecten                                                                                                      |                                      |
| objecten.configuration.data | string | `""` |  |
| objecten.configuration.demo.enabled | bool | `false` |  |
| objecten.configuration.enabled | bool | `true` |  |
| objecten.configuration.initContainer.enabled | bool | `false` |  |
| objecten.configuration.job.backoffLimit | int | `6` |  |
| objecten.configuration.job.enabled | bool | `true` |  |
| objecten.configuration.job.resources | object | `{}` |  |
| objecten.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| objecten.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| objecten.configuration.oidcSecret | string | `"<objecten>"` |  |
| objecten.configuration.oidcUrl | string | `"https://objecten.example.nl"` |  |
| objecten.configuration.secrets | object | `{}` |  |
| objecten.settings.allowedHosts                     | List if allowed hostnames<br/>(i.e. "objecten.example.nl,objecten.podiumd.svc.cluster.local")                                                         | `objecten.podiumd.svc.cluster.local` |
| objecten.settings.database.host                    | Database host. Overides global.settings.databaseHost                                                                                                  | `""`                                 |
| objecten.settings.database.port                    | Database port                                                                                                                                         | `5432`                               |
| objecten.settings.database.name                    | Database name                                                                                                                                         | `""`                                 |
| objecten.settings.database.username                | Database username                                                                                                                                     | `""`                                 |
| objecten.settings.database.password                | Database user password                                                                                                                                | `""`                                 |
| objecten.settings.database.sslmode                 | Database SSL mode                                                                                                                                     | `prefer`                             |
| objecten.settings.email.host                       | Email host                                                                                                                                            | `localhost`                          |
| objecten.settings.email.port                       | Email port                                                                                                                                            | `587`                                |
| objecten.settings.email.username                   | Email username                                                                                                                                        | `""`                                 |
| objecten.settings.email.password                   | Email user password                                                                                                                                   | `""`                                 |
| objecten.settings.email.useTLS                     | Email use TLS                                                                                                                                         | `true`                               |
| objecten.settings.secretKey                        | Django secret key. Generate secret key at https://djecrety.ir/                                                                                        | `""`                                 |
| objecten.settings.environment                      | Sets the `ENVIRONMENT` variable                                                                                                                       | `""`                                 |
| objecten.settings.isHttps                          | Use HTTPS                                                                                                                                             | `true`                               |
| objecten.settings.debug                            | Enable debug mode                                                                                                                                     | `false`                              |
| objecten.settings.sentry.dsn                       | Url to Sentry (i.e https://sentry.example.com/111)                                                                                                    | `""`                                 |
| objecten.persistence.existingClaim                 | Manually managed Persistent Volume and Claim                                                                                                          | `objecten`                           |
| objecten.persistence.mediaMountSubpath             | Media mount subpath                                                                                                                                   | `objecten/media`                     |
| objecten.persistence.size                          | Size of created PersistentVolume                                                                                                                      | `10Gi`                               |
| objecten.persistentVolume.volumeAttributeShareName | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overriden by `.Values.persistentVolume.volumeAttributeShareName` | `objecten`                           |
| objecten.image.repository                          | Image repository                                                                                                                                      | `maykinmedia/objects-api`            |
| objecten.image.tag                                 | Image tag                                                                                                                                             | `2.4.4`                              |
| objecten.image.pullPolicy                          | Image pull policy                                                                                                                                     | `IfNotPresent`                       |
| objecten.nodeSelector                              | Node labels for pod assignment. Evaluated as a template                                                                                               | `{}`                                 |
| objecten.resources                                 | Container requests and limits                                                                                                                         | see values.yaml                      |
| objecten.worker.resources                          | Worker container requests and limits                                                                                                                  | see values.yaml                      |
| objecten.redis.image.registry                      | Redis image registry                                                                                                                                  | `docker.io`                          |
| objecten.redis.image.repository                    | Redis image repository                                                                                                                                | `bitnami/redis`                      |
| objecten.redis.image.tag                           | Redis image tag                                                                                                                                       | `7.0.5-debian-11-r25`                |
| objecten.redis.image.pullPolicy                    | Redis image pul policy                                                                                                                                | `IfNotPresent`                       |
| objecten.redis.master.persistence.enabled          | Redis master persistence enabled                                                                                                                      | `true`                               |
| objecten.redis.master.persistence.size             | Redis master persistence size                                                                                                                         | `"8Gi"`                              |
| objecten.redis.master.persistence.storageClass     | Redis master persistence storage class                                                                                                                | `""`                                 |
| objecten.redis.master.nodeSelector                 | Redis node labels for pod assignment. Evaluated as a template                                                                                         | `{}`                                 |

### Objecttypen

| Name                                              | Description                                                                                         | Value                                   |
|---------------------------------------------------|-----------------------------------------------------------------------------------------------------|-----------------------------------------|
| objecttypen.enabled                               | Boolean to override the installation of objecttypen                                                 |                                         |
| objecttypen.configuration.data | string | `""` |  |
| objecttypen.configuration.enabled | bool | `true` |  |
| objecttypen.configuration.initContainer.enabled | bool | `false` |  |
| objecttypen.configuration.job.backoffLimit | int | `6` |  |
| objecttypen.configuration.job.enabled | bool | `true` |  |
| objecttypen.configuration.job.resources | object | `{}` |  |
| objecttypen.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| objecttypen.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| objecttypen.configuration.oidcSecret | string | `"<objecttypen>"` |  |
| objecttypen.configuration.oidcUrl | string | `"https://objecttypen.example.nl"` |  |
| objecttypen.configuration.secrets | object | `{}` |  |
| objecttypen.configuration.token | string | `"<token>"` |  |
| objecttypen.settings.allowedHosts                 | List if allowed hostnames<br/>(i.e. "objecttypen.example.nl,objecttypen.podiumd.svc.cluster.local") | `objecttypen.podiumd.svc.cluster.local` |
| objecttypen.settings.database.host                | Database host. Overides global.settings.databaseHost                                                | `""`                                    |
| objecttypen.settings.database.port                | Database port                                                                                       | `5432`                                  |
| objecttypen.settings.database.name                | Database name                                                                                       | `""`                                    |
| objecttypen.settings.database.username            | Database username                                                                                   | `""`                                    |
| objecttypen.settings.database.password            | Database user password                                                                              | `""`                                    |
| objecttypen.settings.database.sslmode             | Database SSL mode                                                                                   | `prefer`                                |
| objecttypen.settings.email.host                   | Email host                                                                                          | `localhost`                             |
| objecttypen.settings.email.port                   | Email port                                                                                          | `587`                                   |
| objecttypen.settings.email.username               | Email username                                                                                      | `""`                                    |
| objecttypen.settings.email.password               | Email user password                                                                                 | `""`                                    |
| objecttypen.settings.email.useTLS                 | Email use TLS                                                                                       | `true`                                  |
| objecttypen.settings.secretKey                    | Django secret key. Generate secret key at https://djecrety.ir/                                      | `""`                                    |
| objecttypen.settings.environment                  | Sets the `ENVIRONMENT` variable                                                                     | `""`                                    |
| objecttypen.settings.debug                        | Enable debug mode                                                                                   | `false`                                 |
| objecttypen.settings.sentry.dsn                   | Url to Sentry (i.e https://sentry.example.com/111)                                                  | `""`                                    |
| objecttypen.image.repository                      | Image repository                                                                                    | `maykinmedia/objecttypes-api`           |
| objecttypen.image.tag                             | Image tag                                                                                           | `2.2.2`                                 |
| objecttypen.image.pullPolicy                      | Image pull policy                                                                                   | `IfNotPresent`                          |
| objecttypen.nodeSelector                          | Node labels for pod assignment. Evaluated as a template                                             | `{}`                                    |
| objecttypen.resources                             | Container requests and limits                                                                       | See values.yaml                         |
| objecttypen.redis.image.registry                  | Redis image registry                                                                                | `docker.io`                             |
| objecttypen.redis.image.repository                | Redis image repository                                                                              | `bitnami/redis`                         |
| objecttypen.redis.image.tag                       | Redis image tag                                                                                     | `7.0.5-debian-11-r25`                   |
| objecttypen.redis.image.pullPolicy                | Redis image pul policy                                                                              | `IfNotPresent`                          |
| objecttypen.redis.master.persistence.enabled      | Redis master persistence enabled                                                                    | `true`                                  |
| objecttypen.redis.master.persistence.size         | Redis master persistence size                                                                       | `"8Gi"`                                 |
| objecttypen.redis.master.persistence.storageClass | Redis master persistence storage class                                                              | `""`                                    |
| objecttypen.redis.master.nodeSelector             | Redis node labels for pod assignment. Evaluated as a template                                       | `{}`                                    |

### Open Archiefbeheer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| openarchiefbeheer.configuration.data | string | `""` |  |
| openarchiefbeheer.configuration.enabled | bool | `false` |  |
| openarchiefbeheer.configuration.job.backoffLimit | int | `6` |  |
| openarchiefbeheer.configuration.job.enabled | bool | `true` |  |
| openarchiefbeheer.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| openarchiefbeheer.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| openarchiefbeheer.configuration.oidcSecret | string | `"abc"` |  |
| openarchiefbeheer.configuration.oidcUrl | string | `"https://abc.example.nl"` |  |
| openarchiefbeheer.configuration.secrets | object | `{}` |  |
| openarchiefbeheer.enabled | bool | `true` |  |
| openarchiefbeheer.fullnameOverride | string | `"openarchiefbeheer"` |  |
| openarchiefbeheer.image.tag | string | `"1.0.0"` |  |
| openarchiefbeheer.nameOverride | string | `"openarchiefbeheer"` |  |
| openarchiefbeheer.redis.architecture | string | `"standalone"` |  |
| openarchiefbeheer.redis.auth.enabled | bool | `false` |  |
| openarchiefbeheer.redis.fullnameOverride | string | `"openarchiefbeheer-redis"` |  |
| openarchiefbeheer.redis.master.persistence.enabled | bool | `true` |  |
| openarchiefbeheer.redis.master.persistence.size | string | `"8Gi"` |  |
| openarchiefbeheer.redis.master.persistence.storageClass | string | `""` |  |
| openarchiefbeheer.redis.master.resources.requests.cpu | string | `"10m"` |  |
| openarchiefbeheer.redis.master.resources.requests.memory | string | `"20Mi"` |  |
| openarchiefbeheer.redis.nameOverride | string | `"openarchiefbeheer-redis"` |  |
| openarchiefbeheer.replicaCount | int | `1` |  |
| openarchiefbeheer.resources.limits | object | `{}` |  |
| openarchiefbeheer.resources.requests.cpu | string | `"250m"` |  |
| openarchiefbeheer.resources.requests.memory | string | `"256Mi"` |  |
| openarchiefbeheer.settings.allowedHosts | string | `"openarchiefbeheer.podiumd.svc.cluster.local"` |  |
| openarchiefbeheer.settings.environment | string | `""` | Name of the environment (used for displaying purposes) |
| openarchiefbeheer.settings.frontend.apiPath | string | `"/api/v1"` |  |
| openarchiefbeheer.settings.frontend.apiUrl | string | `""` |  |
| openarchiefbeheer.settings.frontend.zaakUrlTemplate | string | `""` |  |
| openarchiefbeheer.settings.frontendUrl | string | `""` |  |
| openarchiefbeheer.settings.requestsReadTimeout | string | `"5000"` |  |
| openarchiefbeheer.settings.retry.backoffFactor | string | `""` |  |
| openarchiefbeheer.settings.retry.statusForcelist | string | `""` |  |
| openarchiefbeheer.settings.retry.total | string | `""` |  |
| openarchiefbeheer.settings.waitingPeriod | string | `""` | Number of days to wait before destroying a list. Defaults to 7 in the application. |
| openarchiefbeheer.tags.redis | bool | `true` |  |

### Open Klant

| Name                                            | Description                                                                                     | Value                                 |
|-------------------------------------------------|-------------------------------------------------------------------------------------------------|---------------------------------------|
| openklant.configuration.data | string | `""` |  |
| openklant.configuration.enabled | bool | `true` |  |
| openklant.configuration.initContainer.enabled | bool | `false` |  |
| openklant.configuration.job.backoffLimit | int | `6` |  |
| openklant.configuration.job.enabled | bool | `true` |  |
| openklant.configuration.job.resources | object | `{}` |  |
| openklant.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| openklant.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| openklant.configuration.oidcSecret | string | `"<openklant>"` |  |
| openklant.configuration.oidcUrl | string | `"https://openklant.example.nl"` |  |
| openklant.configuration.secrets | object | `{}` |  |
| openklant.settings.allowedHosts                 | List if allowed hostnames<br/>(i.e. "openklant.example.nl,openklant.podiumd.svc.cluster.local") | `openklant.podiumd.svc.cluster.local` |
| openklant.settings.database.host                | Database host                                                                                   | `""`                                  |
| openklant.settings.database.port                | Database port                                                                                   | `5432`                                |
| openklant.settings.database.name                | Database name                                                                                   | `""`                                  |
| openklant.settings.database.username            | Database username                                                                               | `""`                                  |
| openklant.settings.database.password            | Database user password                                                                          | `""`                                  |
| openklant.settings.database.sslmode             | Database SSL mode                                                                               | `prefer`                              |
| openklant.settings.email.host                   | Email host                                                                                      | `localhost`                           |
| openklant.settings.email.port                   | Email port                                                                                      | `587`                                 |
| openklant.settings.email.username               | Email username                                                                                  | `""`                                  |
| openklant.settings.email.password               | Email user password                                                                             | `""`                                  |
| openklant.settings.email.useTLS                 | Email use TLS                                                                                   | `true`                                |
| openklant.settings.secretKey                    | Django secret key. Generate secret key at https://djecrety.ir/                                  | `""`                                  |
| openklant.settings.environment                  | Sets the `ENVIRONMENT` variable                                                                 | `""`                                  |
| openklant.settings.isHttps                      | Use HTTPS                                                                                       | `true`                                |
| openklant.settings.debug                        | Enable debug mode                                                                               | `false`                               |
| openklant.settings.sentry.dsn                   | Url to Sentry (i.e https://sentry.example.com/111)                                              | `""`                                  |
| openklant.image.repository                      | Image repository                                                                                | `maykinmedia/objects-api`             |
| openklant.image.tag                             | Image tag                                                                                       | `2.3.0`                               |
| openklant.image.pullPolicy                      | Image pull policy                                                                               | `IfNotPresent`                        |
| openklant.nodeSelector                          | Node labels for pod assignment. Evaluated as a template                                         | `{}`                                  |
| openklant.resources                             | Container requests and limits                                                                   | See values.yaml                       |
| openklant.worker.resources                      | Worker container requests and limits                                                            | See values.yaml                       |
| openklant.redis.image.registry                  | Redis image registry                                                                            | `docker.io`                           |
| openklant.redis.image.repository                | Redis image repository                                                                          | `bitnami/redis`                       |
| openklant.redis.image.tag                       | Redis image tag                                                                                 | `7.0.5-debian-11-r25`                 |
| openklant.redis.image.pullPolicy                | Redis image pul policy                                                                          | `IfNotPresent`                        |
| openklant.redis.master.persistence.enabled      | Redis master persistence enabled                                                                | `true`                                |
| openklant.redis.master.persistence.size         | Redis master persistence size                                                                   | `"8Gi"`                               |
| openklant.redis.master.persistence.storageClass | Redis master persistence storage class                                                          | `""`                                  |
| openklant.redis.master.nodeSelector             | Redis node labels for pod assignment. Evaluated as a template                                   | `{}`                                  |

### Open Formulieren

| Name                                                      | Description                                                                                                                                           | Value                                             |
|-----------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------|
| openformulieren.enabled                                   | Boolean to override the installation of Open Formulieren                                                                                              |                                                   |
| openformulieren.configuration.data | string | `""` |  |
| openformulieren.configuration.enabled | bool | `true` |  |
| openformulieren.configuration.job.backoffLimit | int | `6` |  |
| openformulieren.configuration.job.enabled | bool | `true` |  |
| openformulieren.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| openformulieren.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| openformulieren.configuration.oidcSecret | string | `"<openformulieren>"` |  |
| openformulieren.configuration.oidcUrl | string | `"https://openformulieren.example.nl"` |  |
| openformulieren.configuration.secrets | object | `{}` |  |
| openformulieren.settings.allowedHosts                     | List of allowed hostnames<br/>(i.e. "openformulieren.example.nl,openformulieren-nginx.podiumd.svc.cluster.local")                                     | `openformulieren-nginx.podiumd.svc.cluster.local` |
| openformulieren.settings.baseUrl                          | Base URL (i.e. "https://openformulieren.example.nl")                                                                                                  | `""`                                              |
| openformulieren.settings.database.host                    | Database host                                                                                                                                         | `""`                                              |
| openformulieren.settings.database.port                    | Database port                                                                                                                                         | `5432`                                            |
| openformulieren.settings.database.name                    | Database name                                                                                                                                         | `""`                                              |
| openformulieren.settings.database.username                | Database username                                                                                                                                     | `""`                                              |
| openformulieren.settings.database.password                | Database user password                                                                                                                                | `""`                                              |
| openformulieren.settings.database.sslmode                 | Database SSL mode                                                                                                                                     | `prefer`                                          |
| openformulieren.settings.email.host                       | Email host                                                                                                                                            | `localhost`                                       |
| openformulieren.settings.email.port                       | Email port                                                                                                                                            | `587`                                             |
| openformulieren.settings.email.username                   | Email username                                                                                                                                        | `""`                                              |
| openformulieren.settings.email.password                   | Email user password                                                                                                                                   | `""`                                              |
| openformulieren.settings.email.useTLS                     | Email use TLS                                                                                                                                         | `true`                                            |
| openformulieren.settings.email.defaultFrom                | Email default `from` email address                                                                                                                    | `""`                                              |
| openformulieren.settings.secretKey                        | Django secret key. Generate secret key at https://djecrety.ir/                                                                                        | `""`                                              |
| openformulieren.settings.environment                      | Sets the `ENVIRONMENT` variable                                                                                                                       | `""`                                              |
| openformulieren.settings.isHttps                          | Use HTTPS                                                                                                                                             | `true`                                            |
| openformulieren.settings.debug                            | Enable debug mode                                                                                                                                     | `false`                                           |
| openformulieren.settings.sentry.dsn                       | Url to Sentry (i.e https://sentry.example.com/111)                                                                                                    | `""`                                              |
| openformulieren.settings.cors.allowedOrigins              | List of allowed origins                                                                                                                               | `[]`                                              |
| openformulieren.settings.csp.reportSave                   |                                                                                                                                                       | `false`                                           |
| openformulieren.settings.numProxies                       | Number of proxies                                                                                                                                     | `1`                                               |
| openformulieren.persistence.existingClaim                 | Manually managed Persistent Volume and Claim                                                                                                          | `openformulieren`                                 |
| openformulieren.persistence.mediaMountSubpath             | Media mount subpath                                                                                                                                   | `openformulieren/media`                           |
| openformulieren.persistence.privateMediaMountSubpath      | Private media mount subpath                                                                                                                           | `openformulieren/private_media`                   |
| openformulieren.persistence.size                          | Size of created PersistentVolume                                                                                                                      | `10Gi`                                            |
| openformulieren.persistentVolume.volumeAttributeShareName | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overriden by `.Values.persistentVolume.volumeAttributeShareName` | `openformulieren`                                 |
| openformulieren.image.repository                          | Image repository                                                                                                                                      | `openformulieren/open-forms`                      |
| openformulieren.image.tag                                 | Image tag                                                                                                                                             | `2.7.8`                                           |
| openformulieren.image.pullPolicy                          | Image pull policy                                                                                                                                     | `IfNotPresent`                                    |
| openformulieren.extraVolumes                              | Optionally specify extra list of additional volumes                                                                                                   | `[]`                                              |
| openformulieren.extraVolumeMounts                         | Optionally specify extra list of additional volumeMounts                                                                                              | `[]]`                                             |
| openformulieren.extraVerifyCerts                          | Path to extra certificates or CA (root) certificates, comma seperated                                                                                 | `""`                                              |
| openformulieren.nodeSelector                              | Node labels for pod assignment. Evaluated as a template                                                                                               | `{}`                                              |
| openformulieren.resources                                 | Container requests and limits                                                                                                                         | See values.yaml                                   |
| openformulieren.worker.resources                          | Worker container requests and limits                                                                                                                  | See values.yaml                                   |
| openformulieren.beat.resources                            | Beat container requests and limits                                                                                                                    | See values.yaml                                   |
| openformulieren.nginx.image.repository                    | Nginx image repository                                                                                                                                | `nginxinc/nginx-unprivileged`                     |
| openformulieren.nginx.image.tag                           | Mginx image tag                                                                                                                                       | `stable`                                          |
| openformulieren.nginx.image.pullPolicy                    | Nginx image pull policy                                                                                                                               | `IfNotPresent`                                    |
| openformulieren.nginx.resources                           | Nginx container requests and limits                                                                                                                   | See values.yaml                                   |
| openformulieren.nginx.config.clientMaxBodySize            | Nginx client max body size                                                                                                                            | `100M`                                            |
| openformulieren.redis.image.registry                      | Redis image registry                                                                                                                                  | `docker.io`                                       |
| openformulieren.redis.image.repository                    | Redis image repository                                                                                                                                | `bitnami/redis`                                   |
| openformulieren.redis.image.tag                           | Redis image tag                                                                                                                                       | `7.0.5-debian-11-r25`                             |
| openformulieren.redis.image.pullPolicy                    | Redis image pul policy                                                                                                                                | `IfNotPresent`                                    |
| openformulieren.redis.master.persistence.enabled          | Redis master persistence enabled                                                                                                                      | `true`                                            |
| openformulieren.redis.master.persistence.size             | Redis master persistence size                                                                                                                         | `"8Gi"`                                           |
| openformulieren.redis.master.persistence.storageClass     | Redis master persistence storage class                                                                                                                | `""`                                              |
| openformulieren.redis.master.nodeSelector                 | Redis node labels for pod assignment. Evaluated as a template                                                                                         | `{}`                                              |

### Open Inwoner

| Name                                                      | Description                                                                                                                                           | Value                                         |
|-----------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|
| openinwoner.enabled                                       | Boolean to override the installation of Open Inwoner                                                                                                  |                                               |
| openinwoner.configuration.data | string | `""` |  |
| openinwoner.configuration.enabled | bool | `true` |  |
| openinwoner.configuration.initContainer.enabled | bool | `false` |  |
| openinwoner.configuration.job.backoffLimit | int | `6` |  |
| openinwoner.configuration.job.enabled | bool | `true` |  |
| openinwoner.configuration.job.resources | object | `{}` |  |
| openinwoner.configuration.job.restartPolicy | string | `"OnFailure"` |  |
| openinwoner.configuration.job.ttlSecondsAfterFinished | int | `0` |  |
| openinwoner.configuration.oidcSecret | string | `"<openinwoner>"` |  |
| openinwoner.configuration.oidcUrl | string | `"https://openinwoner.example.nl"` |  |
| openinwoner.configuration.secrets | object | `{}` |  |
| openinwoner.settings.allowedHosts                         | List if allowed hostnames<br/>(i.e. "openinwoner.example.nl,openinwoner-nginx.podiumd.svc.cluster.local")                                             | `openinwoner-nginx.podiumd.svc.cluster.local` |
| openinwoner.settings.database.host                        | Database host. Overides global.settings.databaseHost                                                                                                  | `""`                                          |
| openinwoner.settings.database.port                        | Database port                                                                                                                                         | `5432`                                        |
| openinwoner.settings.database.name                        | Database name                                                                                                                                         | `""`                                          |
| openinwoner.settings.database.username                    | Database username                                                                                                                                     | `""`                                          |
| openinwoner.settings.database.password                    | Database user password                                                                                                                                | `""`                                          |
| openinwoner.settings.database.sslmode                     | Database SSL mode                                                                                                                                     | `prefer`                                      |
| openinwoner.settings.email.host                           | Email host                                                                                                                                            | `localhost`                                   |
| openinwoner.settings.email.port                           | Email port                                                                                                                                            | `587`                                         |
| openinwoner.settings.email.username                       | Email username                                                                                                                                        | `""`                                          |
| openinwoner.settings.email.password                       | Email user password                                                                                                                                   | `""`                                          |
| openinwoner.settings.email.useTLS                         | Email use TLS                                                                                                                                         | `true`                                        |
| openinwoner.settings.email.defaultFrom                    | Email default `from` email address                                                                                                                    | `""`                                          |
| openinwoner.settings.secretKey                            | Django secret key. Generate secret key at https://djecrety.ir/                                                                                        | `""`                                          |
| openinwoner.settings.environment                          | Sets the `ENVIRONMENT` variable                                                                                                                       | `""`                                          |
| openinwoner.settings.brpVersion                           |                                                                                                                                                       | `""`                                          |
| openinwoner.settings.digidMock                            | Enable the DigiD mock                                                                                                                                 | `""`                                          |
| openinwoner.settings.eherkenningMock                      | Enable the eHerkenning mock                                                                                                                           | `""`                                          |
| openinwoner.settings.isHttps                              | Use HTTPS                                                                                                                                             | `true`                                        |
| openinwoner.settings.debug                                | Enable debug mode                                                                                                                                     | `false`                                       |
| openinwoner.settings.numProxies                           | Number of proxies                                                                                                                                     | `1`                                           |
| openinwoner.settings.sentry.dsn                           | Url to Sentry (i.e https://sentry.example.com/111)                                                                                                    | `""`                                          |
| openinwoner.settings.smsgateway.apikey                    | SMS gateway api key                                                                                                                                   | `""`                                          |
| openinwoner.settings.smsgateway.backend                   | SMS gateway backend                                                                                                                                   | `""`                                          |
| openinwoner.persistence.existingClaim                     | Manually managed Persistent Volume and Claim                                                                                                          | `openinwoner`                                 |
| openinwoner.persistence.mediaMountSubpath                 | Media mount subpath                                                                                                                                   | `openinwoner/media`                           |
| openinwoner.persistence.privateMediaMountSubpath          | Private media mount subpath                                                                                                                           | `openinwoner/private_media`                   |
| openinwoner.persistence.size                              | Size of created PersistentVolume                                                                                                                      | `10Gi`                                        |
| openinwoner.persistentVolume.volumeAttributeShareName     | Value of created PersistentVolume paramer `spec.csi.volumeAttributes.shareName`.<br/>Overriden by `.Values.persistentVolume.volumeAttributeShareName` | `openinwoner`                                 |
| openinwoner.image.repository                              | Image repository                                                                                                                                      | `maykinmedia/open-inwoner`                    |
| openinwoner.image.tag                                     | Image tag                                                                                                                                             | `2.1.2`                                       |
| openinwoner.image.pullPolicy                              | Image pull policy                                                                                                                                     | `IfNotPresent`                                |
| openinwoner.nodeSelector                                  | Node labels for pod assignment. Evaluated as a template                                                                                               | `{}`                                          |
| openinwoner.resources                                     | Container requests and limits                                                                                                                         | See values.yaml                               |
| openinwoner.worker.resources                              | Worker container requests and limits                                                                                                                  | See values.yaml                               |
| openinwoner.nginx.config.clientMaxBodySize                | Nginx client max body size                                                                                                                            | `100M`                                        |
| openinwoner.nginx.image.repository                        | Nginx image repository                                                                                                                                | `nginxinc/nginx-unprivileged`                 |
| openinwoner.nginx.image.tag                               | Mginx image tag                                                                                                                                       | `stable`                                      |
| openinwoner.nginx.image.pullPolicy                        | Nginx image pull policy                                                                                                                               | `IfNotPresent`                                |
| openinwoner.nginx.resources                               | Nginx container requests and limits                                                                                                                   | See values.yaml                               |
| openinwoner.redis.image.registry                          | Redis image registry                                                                                                                                  | `docker.io`                                   |
| openinwoner.redis.image.repository                        | Redis image repository                                                                                                                                | `bitnami/redis`                               |
| openinwoner.redis.image.tag                               | Redis image tag                                                                                                                                       | `7.0.5-debian-11-r25`                         |
| openinwoner.redis.image.pullPolicy                        | Redis image pul policy                                                                                                                                | `IfNotPresent`                                |
| openinwoner.redis.master.persistence.enabled              | Redis master persistence enabled                                                                                                                      | `true`                                        |
| openinwoner.redis.master.persistence.size                 | Redis master persistence size                                                                                                                         | `"8Gi"`                                       |
| openinwoner.redis.master.persistence.storageClass         | Redis master persistence storage class                                                                                                                | `""`                                          |
| openinwoner.redis.master.nodeSelector                     | Redis node labels for pod assignment. Evaluated as a template                                                                                         | `{}`                                          |
| openinwoner.elasticsearch.image.repository                | Elastic search image repository                                                                                                                       | `bitnami/elasticsearch`                       |
| openinwoner.elasticsearch.image.tag                       | Elastic search image tag                                                                                                                              | `8.6.2-debian-11-r0`                          |
| openinwoner.elasticsearch.image.pullPolicy                | Elastic search image pul policy                                                                                                                       | `IfNotPresent`                                |
| openinwoner.elasticsearch.master.persistence.enabled      | Elastic search master persistence enabled                                                                                                             | `true`                                        |
| openinwoner.elasticsearch.master.persistence.size         | Elastic search master persistence storage size                                                                                                        | `"8Gi"`                                       |
| openinwoner.elasticsearch.master.persistence.storageClass | Elastic search master persistence storage class                                                                                                       | `""`                                          |
| openinwoner.elasticsearch.master.nodeSelector             | Elastic search master node labels for pod assignment. Evaluated as a template                                                                         | `{}`                                          |
| openinwoner.elasticsearch.data.persistence.enabled        | Elastic search data persistence enabled                                                                                                               | `true`                                        |
| openinwoner.elasticsearch.data.persistence.size           | Elastic search data persistence storage size                                                                                                          | `"8Gi"`                                       |
| openinwoner.elasticsearch.data.persistence.storageClass   | Elastic search data persistence storage class                                                                                                         | `""`                                          |
| openinwoner.elasticsearch.data.nodeSelector               | Elastic search data node labels for pod assignment. Evaluated as a template                                                                           | `{}`                                          |
| openinwoner.elasticsearch.coordinating.nodeSelector       | Elastic search coordinating node labels for pod assignment. Evaluated as a template                                                                   | `{}`                                          |

### PABC

| Name                                       | Description                                                          | Value                    |
|--------------------------------------------|----------------------------------------------------------------------|--------------------------|
| pabc.enabled                               | Boolean to override the installation of PABC                         | `false`                  |
| pabc.fullnameOverride                      | Override for the full deployment name                                | `"pabc"`                 |
| pabc.image.tag                             | Image tag                                                            | `"1.0.0"`                |
| pabc.migrations.image.tag                  | Migrations image tag                                                 | `"1.0.0"`                |
| pabc.settings.database.host                | Database host                                                        | `""`                     |
| pabc.settings.database.name                | Database name                                                        | `"pabc"`                 |
| pabc.settings.database.username            | Database username                                                    | `"pabc"`                 |
| pabc.settings.database.password            | Database password                                                    | `""`                     |
| pabc.settings.apiKeys                      | List of issued API keys                                              | `[""]`                   |
| pabc.settings.oidc.authority               | URL of the OpenID Connect Identity Provider                          | `""`                     |
| pabc.settings.oidc.clientId                | Client ID for accessing the OpenID Connect Identity Provider         | `"pabc"`                 |
| pabc.settings.oidc.clientSecret            | Secret for the OpenID Connect Identity Provider                      | `""`                     |
| pabc.settings.oidc.functioneelBeheerderRole | Role claim value required for management functions                   | `"administrator"`        |
| pabc.settings.oidc.nameClaimType           | JWT claim name containing the full name of the user                  | `"name"`                 |
| pabc.settings.oidc.roleClaimType           | JWT claim name containing the roles of the user                      | `"roles"`                |
| pabc.settings.oidc.emailClaimType          | JWT claim name containing the email address of the user              | `"email"`                |
| pabc.settings.oidc.oidcUrl                 | OIDC URL                                                             | `"https://pabc.example.nl"` |
| pabc.settings.keycloakAdmin.clientId       | Client ID for accessing Keycloak Admin API                           | `"pabc-keycloak-admin"`  |
| pabc.settings.keycloakAdmin.clientSecret   | Client secret for accessing Keycloak Admin API                       | `""`                     |
| pabc.resources                             | Container requests and limits                                        | See values.yaml          |

### KISS

| Name                                    | Description                                                                                     | Value                                 |
|-----------------------------------------|-------------------------------------------------------------------------------------------------|---------------------------------------|
| kiss.enabled                             | Boolean to override the installation of KISS                                                                 | `true`                                |
| kiss.frontend.image.repository           | Frontend image repository                                                                       | `ghcr.io/klantinteractie-servicesysteem/kiss-frontend` |
| kiss.frontend.image.tag                  | Frontend image tag                                                                              | `"1.3.1"`                             |
| kiss.frontend.image.pullPolicy           | Frontend image pull policy                                                                      | `IfNotPresent`                        |
| kiss.frontend.resources                  | Frontend container requests and limits                                                         | See values.yaml                       |
| kiss.frontend.aspNetCoreEnvironment      | ASP.NET Core environment                                                                        | `Production`                          |
| kiss.frontend.extraEnvVars               | Optionally specify extra list of additional environment variables                               | `[]`                                  |
| kiss.adapter.image.repository             | Adapter image repository                                                                        | `ghcr.io/icatt-menselijk-digitaal/podiumd-adapter` |
| kiss.adapter.image.tag                   | Adapter image tag                                                                               | `"0.6.4"`                             |
| kiss.adapter.image.pullPolicy            | Adapter image pull policy                                                                       | `IfNotPresent`                        |
| kiss.adapter.resources                   | Adapter container requests and limits                                                          | See values.yaml                       |
| kiss.adapter.extraEnvVars                | Optionally specify extra list of additional environment variables                               | `[]`                                  |
| kiss.frontend.extraVolumes               | Optionally specify extra list of additional volumes                                             | `[]`                                  |
| kiss.frontend.extraVolumeMounts          | Optionally specify extra list of additional volumeMounts                                        | `[]`                                  |
| kiss.adapter.extraVolumes                | Optionally specify extra list of additional volumes                                             | `[]`                                  |
| kiss.adapter.extraVolumeMounts           | Optionally specify extra list of additional volumeMounts                                        | `[]`                                  |
| kiss.nodeSelector                        | Node labels for pod assignment. Evaluated as a template                                         | `{}`                                  |

### Podiumd Proxy

| Name                                         | Description                                | Value                                                                               |
|----------------------------------------------|--------------------------------------------|-------------------------------------------------------------------------------------|
| apiproxy.replicaCount                        | Number of replicas to deploy               | `1`                                                                                 |
| apiproxy.nameOverride                        | Override for the deployment name           | `""`                                                                                |
| apiproxy.fullnameOverride                    | Override for the full deployment name      | `""`                                                                                |
| apiproxy.image.repository                    | Container image repository                 | `nginx`                                                                             |
| apiproxy.image.tag                           | Container image tag                        | `"1.25-alpine"`                                                                     |
| apiproxy.image.pullPolicy                    | Image pull policy                          | `IfNotPresent`                                                                      |
| apiproxy.service.port                        | Service port                               | `8081`                                                                              |
| apiproxy.resources.limits.cpu                | CPU resource limit                         | `"0.5"`                                                                             |
| apiproxy.resources.limits.memory             | Memory resource limit                      | `"256Mi"`                                                                           |
| apiproxy.resources.requests.cpu              | CPU resource request                       | `"0.1"`                                                                             |
| apiproxy.resources.requests.memory           | Memory resource request                    | `"128Mi"`                                                                           |
| apiproxy.nginxCertsSecret                    | Secret containing NGINX certificates (empty disables mTLS) | `""`                                                                                |
| apiproxy.sslVerifyDepth                      | Max upstream TLS chain depth (`proxy_ssl_verify_depth`) | `6`                                                                                 |
| apiproxy.livenessProbe.initialDelaySeconds   | Initial delay for liveness probe           | `5`                                                                                 |
| apiproxy.livenessProbe.periodSeconds         | Period between liveness probe checks       | `10`                                                                                |
| apiproxy.readinessProbe.initialDelaySeconds  | Initial delay for readiness probe          | `5`                                                                                 |
| apiproxy.readinessProbe.periodSeconds        | Period between readiness probe checks      | `10`                                                                                |
| apiproxy.locations.*.sslVerify               | SSL verification setting for all locations | `"off"`                                                                             |
| apiproxy.locations.*.hostHeader              | Host header for all locations              | `"lab.api.mijniconnect.nl"`                                                         |
| apiproxy.locations.bag.path                  | Base path for BAG                          | `"/lvbag/individuelebevragingen/v2/"`                                               |
| apiproxy.locations.bag.targetUrl             | Target URL for BAG location                | `"https://lab.api.mijniconnect.nl/iconnect/apibagib/v2/"`                   |
| apiproxy.locations.brp.path                  | Base path for BRP                          | `"/haalcentraal/api/brp"`                                                           |
| apiproxy.locations.brp.targetUrl             | Target URL for BRP location                | `"https://lab.api.mijniconnect.nl/iconnect/apihcbrp/actueel/prtcl/v2/personen"`     |
| apiproxy.locations.kvkSearch.targetUrl       | Target URL for KVK search                  | `"https://lab.api.mijniconnect.nl/iconnect/apikvk/zoeken/v2/zoeken"`                |
| apiproxy.locations.kvkBasic.targetUrl        | Target URL for KVK basic profiles          | `"https://lab.api.mijniconnect.nl/iconnect/apikvk/basprof/v1/v1/basisprofielen"`    |
| apiproxy.locations.kvkBranch.targetUrl       | Target URL for KVK branch profiles         | `"https://lab.api.mijniconnect.nl/iconnect/apikvk/vesprof/v1/v1/vestigingsprofielen"` |

#### Create certificate example
$ kubectl create secret generic api-proxy-certs \
  --from-file=client.crt="C:\labtenant1.lab.api.mijniconnect.nl.crt" \
  --from-file=client.key="C:\labtenant1.lab.api.mijniconnect.nl.key.decrypted" \
  --from-file=ca.crt="C:\lab_api_mijniconnect_nl.crt"

### APISIX

APISIX is deployed as an **outbound (egress) API gateway** for PodiumD applications. PodiumD pods send outbound API calls to the APISIX cluster service for policy enforcement, observability, and (planned) mTLS to upstream services. APISIX is not exposed outside the cluster — no ingress routes are required from APISIX itself.

The chart is wired in via the upstream [`apisix/apisix`](https://github.com/apache/apisix-helm-chart) Helm chart. **Disabled by default** — opt in by setting `apisix.enabled: true`. See `docs/apps/apisix/apisix-egress-gateway.md` for background, the embedded Dashboard UI, route configuration, and the open security TODOs.

The operator GUI is the **embedded APISIX Dashboard**, shipped inside the gateway from APISIX 3.16 onwards and served at the Admin API port (`:9180/ui/`). No separate dashboard chart is required.

| Name                              | Description                                                                                       | Value       |
|-----------------------------------|---------------------------------------------------------------------------------------------------|-------------|
| apisix.enabled                    | Deploy the APISIX egress gateway sub-chart (also enables the embedded Dashboard)                  | `false`     |
| apisix.fullnameOverride           | Override the APISIX release name (so the service is reachable as `apisix.<namespace>.svc...`)     | `"apisix"`  |
| apisix.ingress-controller.enabled | Deploy the bundled ingress controller (kept off — APISIX is egress-only)                          | `false`     |
| apisix.service.type               | Kubernetes service type for the APISIX gateway data plane                                         | `ClusterIP` |
| apisix.admin.enable_admin_ui      | Enable the embedded Dashboard UI on the Admin API port (`:9180/ui/`)                              | `true`      |
| apisix.admin.type                 | Kubernetes service type for the APISIX Admin API + Dashboard                                      | `ClusterIP` |
| apisix.apisixYaml                 | Standalone-mode route/upstream/plugin configuration. See egress-gateway doc for the schema        | _(unset)_   |

For the full upstream values reference run:

```shell
helm show values apisix/apisix --version 2.14.0
```

### Open Beheer

Open Beheer is a Django-based admin/management UI for the ZGW ecosystem — it configures zaaktypes and informatieobjecttypes via the Open Zaak Catalogi API, object schemas via Objecttypen, and references the public Selectielijst API. Deployed as the `openbeheer` sub-chart (`maykinmedia/open-beheer`). **Disabled by default** — opt in by setting `openbeheer.enabled: true`. See `docs/apps/openbeheer/openbeheer.md` for the overview, dependencies, and enable steps, and `docs/apps/openbeheer/openbeheer-known-issues.md` for the uWSGI master-process restart trap.

### Tags

Tags to add additional unreleased PodiumD functionality.

| Name           | Description                          | Value   |
|----------------|--------------------------------------|---------|
| tags.zaak      | Whether PodiumD Zaak is installed    | `false` |

## Upgrading

If an Helm upgrade of a component fails because of a forbidden update to a statefullset spec the statefullset needs to be deleted prior to the Helm upgrade by the following command:

$ kubectl delete sts <component>-redis-master -n podiumd --cascade=orphan

### Upgrading to 4.5.12

The Keycloak Operator ServiceMonitor RBAC resources have been removed from the chart. Helm will automatically delete the `*-keycloak-operator-servicemonitor` ClusterRole and ClusterRoleBinding on upgrade.

However, if you previously ran an earlier version of 4.5.12 (where these resources were still present but renamed from `-view`), or if you are upgrading from 4.5.11, you must also manually remove the orphaned `-view` resources that Helm cannot track:

```
kubectl delete clusterrole <release>-keycloak-operator-servicemonitor-view --ignore-not-found
kubectl delete clusterrolebinding <release>-keycloak-operator-servicemonitor-view --ignore-not-found
```

Replace `<release>` with your Helm release name (default: `podiumd`).

#### ServiceMonitor CRD must be removed

The `monitoring-logging` chart does not manage the `servicemonitors.monitoring.coreos.com` CRD. On clusters where this CRD is present but outdated (built with controller-gen ≤ v0.11.1), the Keycloak Operator will fail with:

```
failed to create typed patch object: .spec.scrapeProtocols: field not declared in schema
```

Remove the CRD from the cluster. This also removes all existing `ServiceMonitor` resources — they will be recreated by their respective operators once a newer CRD is installed:

```
kubectl delete crd servicemonitors.monitoring.coreos.com
```
