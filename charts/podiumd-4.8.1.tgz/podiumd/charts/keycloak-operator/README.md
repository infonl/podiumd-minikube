# keycloak-operator

![Version: 1.12.0](https://img.shields.io/badge/Version-1.12.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 26.6.3](https://img.shields.io/badge/AppVersion-26.6.3-informational?style=flat-square)

Deploy Keycloak Operator and Keycloak

**Homepage:** <https://www.keycloak.org>

## Maintainers
This chart is maintained by [Adfinis](https://adfinis.com/?pk_campaign=github&pk_kwd=helm-charts).

## Source Code

* <https://github.com/keycloak/keycloak-k8s-resources>
* <https://github.com/adfinis/helm-charts/tree/main/charts/keycloak-operator>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fullnameOverride | string | `""` |  |
| grafana.defaultLabel | bool | `true` | Add a default `grafana_dashboard: 1` label |
| grafana.enabled | bool | `false` | Enable Grafana Dashboards |
| grafana.extraLabels | object | `{}` | Labels to add to all Grafana integration resources |
| imagePullSecrets | list | `[]` |  |
| keycloak.additionalOptions | string | `nil` | Configuration of the Keycloak server expressed as a keys and values that can be either direct values or references to secrets. |
| keycloak.admin | object | `{}` | In this section you can find all properties related to making admin connections from the operator to the server. |
| keycloak.bootstrapAdmin | string | `nil` | In this section you can configure Keycloak's bootstrap admin - will be used only for initial cluster creation. |
| keycloak.cache | object | `{}` | Configure keycloaks cache. |
| keycloak.db.database | string | `nil` | Sets the database name of the default JDBC URL of the chosen vendor. If the `url` option is set, this option is ignored. |
| keycloak.db.host | string | `nil` | Sets the hostname of the default JDBC URL of the chosen vendor. If the `url` option is set, this option is ignored. |
| keycloak.db.passwordSecret | string | `nil` | The reference to a secret holding the password of the database user. |
| keycloak.db.poolInitialSize | string | `nil` | The initial size of the connection pool. |
| keycloak.db.poolMaxSize | string | `nil` | The maximum size of the connection pool. |
| keycloak.db.poolMinSize | string | `nil` | The minimal size of the connection pool. |
| keycloak.db.port | string | `nil` | Sets the port of the default JDBC URL of the chosen vendor. If the `url` option is set, this option is ignored. |
| keycloak.db.schema | string | `nil` | The database schema to be used. |
| keycloak.db.url | string | `nil` | The full database JDBC URL. If not provided, a default URL is set based on the selected database vendor. |
| keycloak.db.usernameSecret | string | `nil` | The reference to a secret holding the username of the database user. |
| keycloak.db.vendor | string | `nil` | The database vendor. |
| keycloak.enabled | bool | `false` | Enable deploying a bundled keycloak with the operator |
| keycloak.env | list | `[]` | Environment variables for the Keycloak server. Values can be either direct values or references to secrets. Use additionalOptions for first-class options rather than `KC_` values here. |
| keycloak.features | object | see [Keycloak docs](https://www.keycloak.org/server/features) | Configure Keycloak features |
| keycloak.features.disabled | list | `[]` | Disabled Keycloak features |
| keycloak.features.enabled | list | `[]` | Enabled Keycloak features |
| keycloak.hostname.admin | string | `nil` | The hostname for accessing the administration console. |
| keycloak.hostname.adminUrl | string | `nil` | Set the base URL for accessing the administration console. |
| keycloak.hostname.backchannelDynamic | bool | Use the operator's default if not set. | Enables dynamic resolving of backchannel URLs, including hostname, scheme, port and context path. Set to true if your application accesses Keycloak via a private network. |
| keycloak.hostname.hostname | string | Disabled if not set. | Hostname for the Keycloak server. |
| keycloak.hostname.strict | bool | `false` | Disables dynamically resolving the hostname from request headers |
| keycloak.http.annotations | string | `nil` | Annotations to be appended to the Service object |
| keycloak.http.httpEnabled | bool | `true` | Enable a HTTP listener |
| keycloak.http.httpPort | string | `nil` | The used HTTP port |
| keycloak.http.httpsPort | string | `nil` | The used HTTPS port |
| keycloak.http.labels | string | `nil` | Labels to be appended to the Service object |
| keycloak.http.serviceHttpPort | string | `nil` | The HTTP port exposed on the Kubernetes Service. |
| keycloak.http.serviceHttpsPort | string | `nil` | The HTTPS port exposed on the Kubernetes Service. |
| keycloak.http.serviceName | string | `nil` | The name of the Kubernetes Service. |
| keycloak.http.tlsSecret | string | `nil` | A secret containing the TLS configuration for HTTPS. |
| keycloak.httpManagement.port | string | `nil` | Port of management interface. |
| keycloak.image.repository | string | `""` | Overrides the operator.keycloakImage.image value whose default is quay.io/keycloak/keycloak |
| keycloak.image.sha | string | `""` | Configure the SHA for the keycloak image. Should match the SHA of the image tag if specified or the image tag resolved from the chart appVersion. |
| keycloak.image.tag | string | `""` | Overrides the operator.keycloakImage.tag value whose default is the chart appVersion. |
| keycloak.imagePullSecrets | string | `nil` | Secret(s) that might be used when pulling an image from a private container image registry or repository. |
| keycloak.import | string | `nil` | In this section you can configure import jobs scheduling |
| keycloak.ingress.annotations | object | `{}` | Annotations for the Ingress |
| keycloak.ingress.className | string | `""` | Ingress class name |
| keycloak.ingress.enabled | bool | `true` | The deployment is, by default, exposed through a basic ingress. |
| keycloak.ingress.labels | object | `{}` | Additional labels to be appended to the Ingress object |
| keycloak.ingress.tlsSecret | string | `nil` | A secret containing the TLS configuration for re-encrypt or TLS termination scenarios. Reference: https://kubernetes.io/docs/concepts/configuration/secret/#tls-secrets |
| keycloak.instances | int | `1` | Number of Keycloak instances in HA mode. |
| keycloak.livenessProbe | string | `nil` | Configuration for liveness probe, by default it is 10 for periodSeconds and 3 for failureThreshold |
| keycloak.proxy.headers | string | `""` | The proxy headers that should be accepted by the server. Misconfiguration might leave the server exposed to security vulnerabilities. |
| keycloak.readinessProbe | string | `nil` | Configuration for readiness probe, by default it is 10 for periodSeconds and 3 for failureThreshold |
| keycloak.realmimport.enabled | bool | `false` | Deploy realmimport resources |
| keycloak.realmimport.realms | list | `[]` | A list of realms to configure using the realmimport CRD. |
| keycloak.resources | object | `{}` | Compute Resources required by Keycloak container |
| keycloak.scheduling | string | `nil` | In this section you can configure Keycloak's scheduling |
| keycloak.serviceMonitor | object | `{"annotations":{},"enabled":false,"interval":"30s","labels":{},"scrapeTimeout":"10s"}` | Configuration related to the generated ServiceMonitor |
| keycloak.serviceMonitor.annotations | object | `{}` | Annotations to be appended to the ServiceMonitor object |
| keycloak.serviceMonitor.enabled | bool | `false` | Enables or disables the creation of the ServiceMonitor. |
| keycloak.serviceMonitor.interval | string | `"30s"` | Interval at which metrics should be scraped |
| keycloak.serviceMonitor.labels | object | `{}` | Labels to be appended to the ServiceMonitor object |
| keycloak.serviceMonitor.scrapeTimeout | string | `"10s"` | Timeout after which the scrape is ended |
| keycloak.startOptimized | string | `nil` |  |
| keycloak.startupProbe | string | `nil` | Configuration for startup probe, by default it is 1 for periodSeconds and 600 for failureThreshold |
| keycloak.telemetry | object | `{}` | In this section you can configure general shared OpenTelemetry settings for Keycloak. |
| keycloak.transaction.xaEnabled | bool | `false` | Determine whether Keycloak should use a non-XA datasource. |
| keycloak.truststores | object | `{}` | Configure Keycloak truststores. |
| keycloak.unsupported | object | `{}` | Additional values that will be merged with the operator's defaults |
| keycloak.update | object | `{}` | Configuration related to Keycloak deployment updates. |
| nameOverride | string | `""` |  |
| operator.affinity | object | `{}` | Affinity for Operator Deployment. |
| operator.config.keycloakImage.repository | string | `"quay.io/keycloak/keycloak"` | Default keycloak image to use if non was specified in the Keycloak CRD. |
| operator.config.keycloakImage.sha | string | `"5fdbf2dbb5897cc34e82de49d13e23db011f9925089dbc555fc095f2c8bc1dac"` | Configure the SHA for the default keycloak image. Should match the SHA of the image tag if specified or the image tag resolved from the chart appVersion. |
| operator.config.keycloakImage.tag | string | `""` | Overrides the keycloak image tag whose default is the chart appVersion. |
| operator.deploymentAnnotations | object | `{}` | Annotations to set on the Operator Deployment. |
| operator.enabled | bool | `true` | Enable deploying the keycloak-operator |
| operator.image.pullPolicy | string | `"IfNotPresent"` | Pull policy for Operator. |
| operator.image.repository | string | `"quay.io/keycloak/keycloak-operator"` | Operator Image source. |
| operator.image.sha | string | `"bd128cd63da5b1e64514903ced8def912a41a6ae63d1569fd39022c586680087"` | Configure the SHA for the operator image. Should match the SHA of the image tag if specified or the image tag resolved from the chart appVersion. |
| operator.image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| operator.nodeSelector | object | `{}` | Node selector for Operator Deployment. |
| operator.podAnnotations | object | `{}` | Annotations to set on the Operator Pod. |
| operator.podSecurityContext | object | `{}` | Pod security group configuration for Operator Deployment. |
| operator.podTopologySpreadConstraints | object | `{}` | Pod Topology Spread Constraints for Operator Deployment |
| operator.replicaCount | int | `1` | Number or oeprator pods to start. |
| operator.resources | object | `{}` | Resource requests and limits for Operator Deployment. |
| operator.roles.enableServiceMonitor | bool | `false` | Enable managing of serviceMonitors, required for keycloak.serviceMonitor.enabled=true. |
| operator.securityContext | object | `{}` | Security context for Operator Deployment. |
| operator.service.enabled | bool | `true` | Enable creation of Service |
| operator.service.port | int | `8080` | Service port for Operator. |
| operator.service.type | string | `"ClusterIP"` | Service type for Operator. |
| operator.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| operator.serviceAccount.create | bool | `true` | Specifies whether a service account should be created. |
| operator.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| operator.tolerations | list | `[]` | Tolerations for Operator Deployment. |

## About this chart

Adfinis fights for a software world that is more open, where the quality is
better and where software must be accessible to everyone. This chart
is part of the action behind this commitment. Feel free to
[contact](https://adfinis.com/kontakt/?pk_campaign=github&pk_kwd=helm-charts)
us if you have any questions.

## License

This Helm chart is free software: you can redistribute it and/or modify it under the terms
of the GNU Affero General Public License as published by the Free Software Foundation,
version 3 of the License.

----------------------------------------------
Autogenerated from chart metadata using [helm-docs](https://github.com/norwoodj/helm-docs/)
